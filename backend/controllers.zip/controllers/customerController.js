const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { getContractInstance, registerUser } = require('../fabric/network');
const { Customer } = require('../database/models');
const { initializePaymentWallet, getWalletBalanceById } = require('../utils/walletUtils'); // ✅ Corrected import

// ✅ Get customer profile
const getCustomerProfile = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      console.log(`📘 Getting profile for customer: ${customerId}`);
      const customerData = await contract.evaluateTransaction('GetCustomer', customerId);
      const customer = JSON.parse(customerData.toString());

      // 🔧 Initialize wallet for virtual payments if not exists
      await initializePaymentWallet(customerId);
      const walletDetails = await getWalletBalanceById(customerId);

      res.json({
        id: customer.ID || customer.id,
        name: customer.Name || customer.name,
        email: customer.Email || customer.email,
        phone: customer.Phone || customer.phone,
        visibility: customer.Visibility || customer.visibility,
        registeredDate: customer.RegisteredDate || customer.registeredDate,
        isActive: customer.IsActive ?? customer.isActive,
        bookings: customer.BookingHistory || customer.bookingHistory || [],
        virtualWallet: walletDetails
      });
    } catch (error) {
      console.error(`❌ Error getting customer profile: ${error}`);
      res.status(500).json({ error: `Failed to get customer profile: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`❌ Error in getCustomerProfile: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Update customer visibility
const updateVisibility = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { visibility } = req.body;

    if (!visibility || !['public', 'anonymous'].includes(visibility)) {
      return res.status(400).json({ error: 'Invalid visibility value. Must be "public" or "anonymous"' });
    }

    const { gateway, contract } = await getContractInstance(customerId);

    try {
      console.log(`📤 Updating visibility for ${customerId} to ${visibility}`);
      await contract.submitTransaction('UpdateCustomerVisibility', customerId, visibility);

      res.json({
        message: 'Visibility updated successfully',
        visibility
      });
    } catch (error) {
      console.error(`❌ Error updating customer visibility: ${error}`);
      res.status(500).json({ error: `Failed to update visibility: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`❌ Error in updateVisibility: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Get customer bookings
const getCustomerBookings = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      console.log(`📘 Fetching bookings for customer: ${customerId}`);
      const bookingsData = await contract.evaluateTransaction('QueryCustomerBookings', customerId);
      const bookings = JSON.parse(bookingsData.toString());

      const bookingsWithTickets = await Promise.all(
        bookings.map(async (booking) => {
          const ticketData = await contract.evaluateTransaction('GetTicket', booking.TicketID || booking.ticketId);
          const ticket = JSON.parse(ticketData.toString());

          return {
            ...booking,
            ticket: {
              id: ticket.ID || ticket.id,
              origin: ticket.Origin || ticket.origin,
              destination: ticket.Destination || ticket.destination,
              departureTime: ticket.DepartureTime || ticket.departureTime,
              arrivalTime: ticket.ArrivalTime || ticket.arrivalTime,
              serviceProvider: ticket.ServiceProvider || ticket.serviceProvider,
              transportMode: ticket.TransportMode || ticket.transportMode,
              price: ticket.Price || ticket.price,
              dynamicPrice: ticket.DynamicPrice || ticket.dynamicPrice
            }
          };
        })
      );

      res.json(bookingsWithTickets);
    } catch (error) {
      console.error(`❌ Error getting customer bookings: ${error}`);
      res.status(500).json({ error: `Failed to get bookings: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`❌ Error in getCustomerBookings: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Deactivate customer account
const deactivateAccount = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { gateway, contract } = await getContractInstance(customerId);

    try {
      console.log(`📤 Deregistering customer: ${customerId}`);
      await contract.submitTransaction('DeregisterCustomer', customerId);

      await Customer.findOneAndUpdate({ userId: customerId }, { isActive: false });

      res.json({ message: 'Account deactivated successfully' });
    } catch (error) {
      console.error(`❌ Error deactivating customer account: ${error}`);
      res.status(500).json({ error: `Failed to deactivate account: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`❌ Error in deactivateAccount: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Export all properly
module.exports = {
  getCustomerProfile,
  updateVisibility,
  getCustomerBookings,
  deactivateAccount
};
