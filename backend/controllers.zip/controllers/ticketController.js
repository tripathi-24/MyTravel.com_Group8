const jwt = require('jsonwebtoken');
//const bcrypt = require('bcrypt');
const { registerUser, getContractInstance } = require('../fabric/network');

// Helper to generate 6-character alphanumeric ID
const generateShortId = (prefix) => {
  const randomId = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefix}_${randomId}`;
};

// Register a new customer
exports.registerCustomer = async (data) => {
  const { name, email, phone, password, visibility } = data;
  const userId = generateShortId('customer');

  await registerUser(userId);
  const { gateway, contract } = await getContractInstance(userId);

  await contract.submitTransaction(
    'RegisterCustomer',
    userId,
    name,
    email,
    phone,
    visibility
  );
  gateway.disconnect();

  return { success: true, message: 'Customer registered successfully', userId };
};

// Register a new provider
exports.registerProvider = async (data) => {
  const { name, email, phone, password, transportMode } = data;
  const userId = generateShortId('provider');

  await registerUser(userId);
  const { gateway, contract } = await getContractInstance(userId);

  await contract.submitTransaction(
    'RegisterProvider',
    userId,
    name,
    email,
    phone,
    transportMode
  );
  gateway.disconnect();

  return { success: true, message: 'Provider registered successfully', userId };
};

// Login for customers and providers
exports.login = async (id, password) => {
  const { gateway, contract } = await getContractInstance('admin');
  let userData, role;

  if (id.startsWith('customer_')) {
    userData = JSON.parse(await contract.evaluateTransaction('GetCustomer', id));
    role = 'customer';
  } else if (id.startsWith('provider_')) {
    userData = JSON.parse(await contract.evaluateTransaction('GetProvider', id));
    role = 'provider';
  }

  gateway.disconnect();

  if (!userData || !userData.isActive) throw new Error('Account is inactive or not found on blockchain');

  const token = jwt.sign(
    { id, role, name: userData.name, email: userData.email },
    process.env.JWT_SECRET,
    { expiresIn: '1d' }
  );

  return {
    message: 'Login successful',
    token,
    user: { ...userData, role }
  };
};

// Get all tickets
exports.getAllTickets = async (req, res) => {
  try {
    const {
      source,
      destination,
      date,
      transportMode,
      minPrice,
      maxPrice,
      minRating
    } = req.query;

    const { gateway, contract } = await getContractInstance('admin');

    try {
      let tickets = [];

      if (source && destination && date) {
        const ticketsData = await contract.evaluateTransaction('QueryTicketsByRoute', source, destination, date);
        tickets = JSON.parse(ticketsData.toString());
      } else if (transportMode) {
        const ticketsData = await contract.evaluateTransaction('QueryTicketsByTransportMode', transportMode);
        tickets = JSON.parse(ticketsData.toString());
      } else if (minPrice !== undefined && maxPrice !== undefined) {
        const ticketsData = await contract.evaluateTransaction(
          'QueryTicketsByPriceRange',
          parseFloat(minPrice),
          parseFloat(maxPrice)
        );
        tickets = JSON.parse(ticketsData.toString());
      } else if (minRating) {
        const ticketsData = await contract.evaluateTransaction('QueryTicketsByProviderRating', parseFloat(minRating));
        tickets = JSON.parse(ticketsData.toString());
      } else {
        const dummyDate = new Date().toISOString().split('T')[0];
        const ticketsData = await contract.evaluateTransaction('QueryTicketsByRoute', '', '', dummyDate);
        tickets = JSON.parse(ticketsData.toString());
      }

      const ticketsWithProvider = await Promise.all(
        tickets.map(async (ticket) => {
          try {
            const providerData = await contract.evaluateTransaction('GetProvider', ticket.serviceProvider);
            const provider = JSON.parse(providerData.toString());
            return {
              ...ticket,
              provider: {
                id: provider.id,
                name: provider.name,
                rating: provider.rating,
                transportMode: provider.transportMode
              }
            };
          } catch (error) {
            return ticket;
          }
        })
      );

      res.json(ticketsWithProvider);
    } catch (error) {
      console.error(`Error getting tickets: ${error}`);
      res.status(500).json({ error: `Failed to get tickets: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getAllTickets: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get ticket by ID
exports.getTicketById = async (req, res) => {
  try {
    const { id } = req.params;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      const ticketData = await contract.evaluateTransaction('GetTicket', id);
      const ticket = JSON.parse(ticketData.toString());

      const providerData = await contract.evaluateTransaction('GetProvider', ticket.serviceProvider);
      const provider = JSON.parse(providerData.toString());

      const response = {
        ...ticket,
        provider: {
          id: provider.id,
          name: provider.name,
          rating: provider.rating,
          transportMode: provider.transportMode
        }
      };

      res.json(response);
    } catch (error) {
      console.error(`Error getting ticket: ${error}`);
      res.status(500).json({ error: `Failed to get ticket: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getTicketById: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get available seats for a ticket
exports.getAvailableSeats = async (req, res) => {
  try {
    const { id } = req.params;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      const seatsData = await contract.evaluateTransaction('QueryAvailableSeats', id);
      const seats = JSON.parse(seatsData.toString());

      res.json(seats);
    } catch (error) {
      console.error(`Error getting available seats: ${error}`);
      res.status(500).json({ error: `Failed to get available seats: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getAvailableSeats: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};
const { Ticket } = require('../database/models'); // ✅ Import once at the top

exports.createTicket = async (req, res) => {
  try {
    const {
      origin,
      destination,
      departureTime,
      arrivalTime,
      price,
      availableSeats,
      totalSeats,
      status,
      serviceProvider,
      transportMode = 'air'
    } = req.body;

    const id = generateShortId('TICKET');

    if (!origin || !destination || !departureTime || !arrivalTime ||
        !price || !availableSeats || !totalSeats || !serviceProvider || !status || !transportMode) {
      return res.status(400).json({ error: 'All ticket fields are required.' });
    }

    console.log("📤 Submitting ticket with args:", [
      id, origin, destination, departureTime, arrivalTime,
      price.toString(), totalSeats.toString(), serviceProvider, transportMode
    ]);

    const { gateway, contract } = await getContractInstance('admin');

    try {
      await contract.submitTransaction(
        'CreateTicket',
        id,
        origin,
        destination,
        departureTime,
        arrivalTime,
        price.toString(),
        totalSeats.toString(),
        serviceProvider,
        transportMode
      );

      // ✅ Save to MongoDB
      const newTicket = new Ticket({
        id,
        origin,
        destination,
        departureTime,
        arrivalTime,
        price,
        availableSeats,
        totalSeats,
        status,
        serviceProvider,
        transportMode
      });

      await newTicket.save();
      console.log(`✅ Ticket also saved to MongoDB with ID: ${id}`);

      res.status(201).json({ message: '✅ Ticket created successfully.', ticketId: id });
    } catch (error) {
      console.error(`❌ Error during blockchain submitTransaction: ${error}`);
      res.status(500).json({ error: `Blockchain Error: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`❌ Error in createTicket handler: ${error}`);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
