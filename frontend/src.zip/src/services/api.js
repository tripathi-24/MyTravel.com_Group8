import axios from 'axios';

// Create axios instance
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:4000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add a request interceptor
api.interceptors.request.use(
  (config) => {
    // Get token from localStorage
    const token = localStorage.getItem('token');
    
    // If token exists, add to headers
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle 401 Unauthorized errors (token expired or invalid)
    if (error.response && error.response.status === 401) {
      // Remove token from localStorage
      localStorage.removeItem('token');
      
      // Redirect to login page if not already there
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);

// For testing purposes, we'll use mock implementations of the API functions
const mockCustomerId = "customer_123abc";
const mockProviderId = "provider_456def";
const mockToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImN1c3RvbWVyXzEyM2FiYyIsInJvbGUiOiJjdXN0b21lciIsIm5hbWUiOiJKb2huIERvZSIsImVtYWlsIjoiam9obmRvZUBleGFtcGxlLmNvbSIsImlhdCI6MTYxNjE1MjM5MCwiZXhwIjoxNjE2MjM4NzkwfQ.znkMS3Qq3CnU7Tg0Uby8qoSfMOsxfj9Sr3ByTGPzR4U";
const mockProviderToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6InByb3ZpZGVyXzQ1NmRlZiIsInJvbGUiOiJwcm92aWRlciIsIm5hbWUiOiJBQ01FIFRyYXZlbCIsImVtYWlsIjoiY29udGFjdEBhY21ldHJhdmVsLmNvbSIsImlhdCI6MTYxNjE1MjM5MCwiZXhwIjoxNjE2MjM4NzkwfQ.XsxEKGXPsK9nZ7Vd7Eq4SkH3_R5UHJ2dACGZC_i6-XA";

export default api;

// Auth services
export const authService = {
  registerCustomer: (data) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/auth/register/customer', data);
    }
    
    // Mock implementation for testing
    console.log("Registering customer:", data);
    return Promise.resolve({
      data: {
        token: mockToken,
        user: {
          id: mockCustomerId,
          name: data.name,
          email: data.email,
          phone: data.phone,
          visibility: data.visibility,
          role: 'customer'
        }
      }
    });
  },
  
  registerProvider: (data) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/auth/register/provider', data);
    }
    
    // Mock implementation for testing
    console.log("Registering provider:", data);
    return Promise.resolve({
      data: {
        token: mockProviderToken,
        user: {
          id: mockProviderId,
          name: data.name,
          email: data.email,
          phone: data.phone,
          transportMode: data.transportMode,
          role: 'provider'
        }
      }
    });
  },
  
  login: (id, password) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/auth/login', { id, password });
    }
    
    // Mock implementation for testing
    console.log("Logging in with ID:", id, "and password:", password);
    
    // Default test password for mock data
    const mockPassword = "password123";
    
    if (id === mockCustomerId && password === mockPassword) {
      return Promise.resolve({
        data: {
          token: mockToken,
          user: {
            id: mockCustomerId,
            firstName: "John",
            lastName: "Doe",
            email: "johndoe@example.com",
            phone: "1234567890",
            visibility: "public",
            role: 'customer'
          }
        }
      });
    } else if (id === mockProviderId && password === mockPassword) {
      return Promise.resolve({
        data: {
          token: mockProviderToken,
          user: {
            id: mockProviderId,
            name: "ACME Travel",
            email: "contact@acmetravel.com",
            phone: "9876543210",
            transportMode: "land",
            serviceType: "Transportation",
            role: 'provider'
          }
        }
      });
    } else {
      return Promise.reject({ 
        response: { 
          data: { error: 'Invalid ID or password. Try using "customer_test" or "provider_test" with password "password123"' }
        }
      });
    }
  },
};

// Customer services
export const customerService = {
  getProfile: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/auth/profile');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        id: mockCustomerId,
        firstName: "John",
        lastName: "Doe",
        email: "johndoe@example.com",
        phone: "1234567890",
        visibility: "public",
      }
    });
  },
  
  updateProfile: (profileData) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put('/auth/profile', profileData);
    }
    
    // Mock implementation for testing
    console.log("Updating customer profile:", profileData);
    return Promise.resolve({
      data: {
        id: mockCustomerId,
        firstName: profileData.firstName || "John",
        lastName: profileData.lastName || "Doe",
        email: profileData.email || "johndoe@example.com",
        phone: profileData.phone || "1234567890",
        visibility: profileData.visibility || "public",
      }
    });
  },
  
  changePassword: (oldPassword, newPassword) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put('/auth/change-password', { currentPassword: oldPassword, newPassword });
    }
    
    // Mock implementation for testing
    console.log("Changing password from", oldPassword, "to", newPassword);
    return Promise.resolve({
      data: {
        success: true,
        message: "Password changed successfully"
      }
    });
  },
  
  getBookings: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/bookings');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        bookings: [
          {
            bookingId: "booking_1",
            providerUserId: mockProviderId,
            serviceType: "Hotel",
            status: "confirmed",
            transactionHash: "0x123456789",
            bookingDate: "2023-06-15T10:00:00Z",
            serviceDate: "2023-07-15T10:00:00Z",
            amount: 120
          }
        ]
      }
    });
  },
  
  createBooking: (providerId, serviceId, serviceDate) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/bookings', { providerId, serviceId, serviceDate });
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        message: "Booking created successfully",
        booking: {
          bookingId: "new_booking_" + Date.now(),
          customerId: mockCustomerId,
          providerUserId: providerId,
          serviceId: serviceId,
          status: "pending",
          transactionHash: "0x" + Math.random().toString(16).substring(2, 10) + "...",
          bookingDate: new Date().toISOString(),
          serviceDate: serviceDate,
          amount: 150
        }
      }
    });
  },
  
  getWalletInfo: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/wallet');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        balance: "500.00",
        address: "0x1234...5678",
        transactions: [
          {
            id: "tx1",
            type: "deposit",
            amount: "100.00",
            status: "completed",
            timestamp: "2023-07-15T10:00:00Z",
            blockchainTxId: "0xabcd...1234"
          },
          {
            id: "tx2",
            type: "payment",
            amount: "75.00",
            status: "completed",
            description: "Hotel Booking",
            timestamp: "2023-07-10T14:30:00Z",
            blockchainTxId: "0xefgh...5678"
          },
          {
            id: "tx3",
            type: "withdraw",
            amount: "25.00",
            status: "completed",
            timestamp: "2023-07-05T09:15:00Z",
            blockchainTxId: "0xijkl...9012"
          }
        ]
      }
    });
  },
  
  depositToWallet: (amount) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/wallet/deposit', { amount });
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        message: "Deposit successful",
        transactionId: "deposit_" + Date.now(),
        blockchainTxId: "0x" + Math.random().toString(16).substring(2, 10) + "...",
        amount
      }
    });
  },
  
  withdrawFromWallet: (amount) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/wallet/withdraw', { amount });
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        message: "Withdrawal successful",
        transactionId: "withdraw_" + Date.now(),
        blockchainTxId: "0x" + Math.random().toString(16).substring(2, 10) + "...",
        amount
      }
    });
  }
};

// Provider services
export const providerService = {
  getProfile: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/auth/profile');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        id: mockProviderId,
        businessName: "ACME Travel",
        email: "contact@acmetravel.com",
        phone: "9876543210",
        transportMode: "land",
        serviceType: "Transportation"
      }
    });
  },
  
  updateProfile: (profileData) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put('/auth/profile', profileData);
    }
    
    // Mock implementation for testing
    console.log("Updating provider profile:", profileData);
    return Promise.resolve({
      data: {
        id: mockProviderId,
        businessName: profileData.name || "ACME Travel",
        email: profileData.email || "contact@acmetravel.com",
        phone: profileData.phone || "9876543210",
        transportMode: profileData.transportMode || "land",
        serviceType: "Transportation"
      }
    });
  },
  
  changePassword: (oldPassword, newPassword) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put('/auth/change-password', { currentPassword: oldPassword, newPassword });
    }
    
    // Mock implementation for testing
    console.log("Changing password from", oldPassword, "to", newPassword);
    return Promise.resolve({
      data: {
        success: true,
        message: "Password changed successfully"
      }
    });
  },
  
  getServices: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/services/provider');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        services: [
          {
            serviceId: "service_1",
            name: "New York to Boston",
            description: "Comfortable bus ride from NYC to Boston",
            price: 120,
            availability: {
              startDate: "2023-06-01T00:00:00Z",
              endDate: "2023-12-31T00:00:00Z",
              recurrence: "daily"
            },
            capacity: 50,
            isActive: true,
            category: "Transportation"
          }
        ]
      }
    });
  },
  
  createService: (serviceData) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.post('/services', serviceData);
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        service: {
          serviceId: "service_" + Math.floor(Math.random() * 1000),
          name: serviceData.name,
          description: serviceData.description,
          price: serviceData.price,
          availability: serviceData.availability,
          capacity: serviceData.capacity,
          isActive: true,
          category: serviceData.category
        }
      }
    });
  },
  
  updateService: (serviceId, serviceData) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put(`/services/${serviceId}`, serviceData);
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        service: {
          serviceId: serviceId,
          name: serviceData.name,
          description: serviceData.description,
          price: serviceData.price,
          availability: serviceData.availability,
          capacity: serviceData.capacity,
          isActive: serviceData.isActive
        }
      }
    });
  },
  
  getBookings: () => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/bookings');
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        bookings: [
          {
            bookingId: "booking_1",
            customerUserId: mockCustomerId,
            serviceId: "service_1",
            status: "confirmed",
            transactionHash: "0x123456789",
            bookingDate: "2023-06-15T10:00:00Z",
            serviceDate: "2023-07-15T10:00:00Z",
            amount: 120
          }
        ]
      }
    });
  }
};

// Common services for both roles
export const commonService = {
  searchServices: (params) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get('/services/search', { params });
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        services: [
          {
            serviceId: "service_1",
            name: "Luxury Hotel Stay",
            description: "Experience luxury at its finest with our premium suite accommodation offering stunning views and top-notch amenities.",
            price: 200,
            category: "Hotel",
            provider: {
              providerId: "provider_1",
              businessName: "Grand Luxury Hotels",
              ratings: {
                average: 4.8,
                count: 245
              }
            }
          },
          {
            serviceId: "service_2",
            name: "City Tour Guide",
            description: "Explore the hidden gems of our city with an experienced local guide who knows all the best spots.",
            price: 75,
            category: "Tour Guide",
            provider: {
              providerId: "provider_2",
              businessName: "Local Explorers",
              ratings: {
                average: 4.6,
                count: 132
              }
            }
          },
          {
            serviceId: "service_3",
            name: "Airport Transfer",
            description: "Comfortable and reliable transfer from the airport to your accommodation.",
            price: 50,
            category: "Transportation",
            provider: {
              providerId: "provider_3",
              businessName: "Swift Transfers",
              ratings: {
                average: 4.7,
                count: 189
              }
            }
          }
        ]
      }
    });
  },
  
  getServiceDetails: (serviceId) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get(`/services/${serviceId}`);
    }
    
    // Mock implementation for testing
    const services = {
      "service_1": {
        serviceId: "service_1",
        name: "Luxury Hotel Stay",
        description: "Experience luxury at its finest with our premium suite accommodation offering stunning views and top-notch amenities. Each room is designed with comfort and style in mind, featuring king-sized beds, rainfall showers, and high-end toiletries. Enjoy access to our rooftop pool, spa, and fitness center during your stay.",
        price: 200,
        category: "Hotel",
        capacity: 2,
        availability: {
          startDate: "2023-01-01T00:00:00Z",
          endDate: "2023-12-31T00:00:00Z"
        },
        provider: {
          providerId: "provider_1",
          businessName: "Grand Luxury Hotels",
          serviceType: "Hotel",
          phone: "+1-555-123-4567",
          ratings: {
            average: 4.8,
            count: 245
          }
        }
      },
      "service_2": {
        serviceId: "service_2",
        name: "City Tour Guide",
        description: "Explore the hidden gems of our city with an experienced local guide who knows all the best spots. Our 4-hour walking tour covers historical landmarks, cultural hotspots, and local favorite eateries. Tours are limited to 8 people to ensure a personalized experience.",
        price: 75,
        category: "Tour Guide",
        capacity: 8,
        availability: {
          startDate: "2023-01-01T00:00:00Z",
          endDate: "2023-12-31T00:00:00Z"
        },
        provider: {
          providerId: "provider_2",
          businessName: "Local Explorers",
          serviceType: "Tour Guide",
          phone: "+1-555-987-6543",
          ratings: {
            average: 4.6,
            count: 132
          }
        }
      },
      "service_3": {
        serviceId: "service_3",
        name: "Airport Transfer",
        description: "Comfortable and reliable transfer from the airport to your accommodation. Our professional drivers will meet you at the arrivals hall and help with your luggage. All vehicles are air-conditioned and well-maintained.",
        price: 50,
        category: "Transportation",
        capacity: 4,
        availability: {
          startDate: "2023-01-01T00:00:00Z",
          endDate: "2023-12-31T00:00:00Z"
        },
        provider: {
          providerId: "provider_3",
          businessName: "Swift Transfers",
          serviceType: "Transportation",
          phone: "+1-555-789-0123",
          ratings: {
            average: 4.7,
            count: 189
          }
        }
      }
    };
    
    return Promise.resolve({
      data: {
        success: true,
        service: services[serviceId] || {
          serviceId: serviceId,
          name: "Unknown Service",
          description: "Details not available",
          price: 0,
          category: "Unknown",
          provider: {
            providerId: "unknown",
            businessName: "Unknown Provider",
            serviceType: "Unknown",
            phone: "N/A"
          }
        }
      }
    });
  },
  
  getBookingDetails: (bookingId) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.get(`/bookings/${bookingId}`);
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        booking: {
          bookingId: bookingId,
          status: "confirmed",
          transactionHash: "0x123456789",
          bookingDate: "2023-06-15T10:00:00Z",
          serviceDate: "2023-07-15T10:00:00Z",
          amount: 120,
          provider: {
            id: mockProviderId,
            businessName: "ACME Travel",
            serviceType: "Transportation",
            phone: "9876543210"
          },
          customer: {
            id: mockCustomerId,
            name: "John Doe",
            phone: "1234567890"
          }
        },
        history: [
          {
            txId: "0xabc123",
            timestamp: "2023-06-15T10:00:00Z",
            value: { status: "pending", updatedBy: "system" }
          },
          {
            txId: "0xdef456",
            timestamp: "2023-06-16T15:30:00Z",
            value: { status: "confirmed", updatedBy: "provider" }
          }
        ]
      }
    });
  },
  
  updateBookingStatus: (bookingId, status) => {
    // Use real API if REACT_APP_USE_MOCK_API is not set to true
    if (process.env.REACT_APP_USE_MOCK_API !== 'true') {
      return api.put(`/bookings/${bookingId}/status`, { status });
    }
    
    // Mock implementation for testing
    return Promise.resolve({
      data: {
        success: true,
        message: `Booking status updated to ${status}`,
        booking: {
          bookingId: bookingId,
          status: status,
          updatedAt: new Date().toISOString()
        }
      }
    });
  }
};

// Ticket services
export const ticketService = {
  searchTickets: (params) => api.get('/api/tickets', { params }),
  getTicketById: (id) => api.get(`/api/tickets/${id}`),
  getAvailableSeats: (id) => api.get(`/api/tickets/${id}/seats`),
};

// Booking services
export const bookingService = {
  bookTicket: (bookingData) => api.post('/api/bookings', bookingData),
  confirmPayment: (paymentData) => api.post('/api/bookings/payment', paymentData),
  getBookingById: (id) => api.get(`/api/bookings/${id}`),
  cancelBooking: (bookingId) => api.put(`/api/bookings/${bookingId}/cancel`),
};

// Payment services
export const paymentService = {
  getWalletBalance: () => api.get('/api/payments/wallet'),
  initializeWallet: () => api.post('/api/payments/wallet/initialize'),
  addFunds: (amount) => api.post('/api/payments/wallet/add-funds', { amount }),
  processPayment: (bookingId, amount) => api.post('/api/payments/process', { bookingId, amount }),
  processRefund: (bookingId, amount) => api.post('/api/payments/refund', { bookingId, amount }),
}; 