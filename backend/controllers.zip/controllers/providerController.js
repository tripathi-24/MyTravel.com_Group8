const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { getContractInstance, registerUser } = require('../fabric/network');
const { Provider } = require('../database/models');
//const { initializeWallet } = require('./walletController'); // ✅ Updated correct import
const { initializePaymentWallet } = require('../utils/walletUtils'); // ✅ Correct

// ✅ Get provider profile
const getProviderProfile = async (req, res) => {
  try {
    const providerId = req.user.id;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      const providerData = await contract.evaluateTransaction('GetProvider', providerId);
      const provider = JSON.parse(providerData.toString());

      res.json({
        id: provider.id,
        name: provider.name,
        email: provider.email,
        phone: provider.phone,
        transportMode: provider.transportMode,
        rating: provider.rating,
        totalRatings: provider.totalRatings,
        registeredDate: provider.registeredDate,
        isActive: provider.isActive,
        transportList: provider.transportList
      });
    } catch (error) {
      console.error(`Error getting provider profile: ${error}`);
      res.status(500).json({ error: `Failed to get provider profile: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getProviderProfile: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Register provider with plain password
const registerProvider = async (req, res) => {
  try {
    const {
      name,
      email,
      phone,
      password,
      transportMode,
      businessName,
      serviceType
    } = req.body;

    if (!name || !email || !phone || !password || !transportMode || !businessName || !serviceType) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const validModes = ['air', 'land', 'water'];
    if (!validModes.includes(transportMode)) {
      return res.status(400).json({ error: 'Invalid transport mode' });
    }

    const providerId = `provider_${uuidv4().slice(0, 6)}`;
    console.log('🟡 Password received:', password);

    await registerUser(providerId);

    const { gateway, contract } = await getContractInstance(providerId);

    try {
      await contract.submitTransaction(
        'RegisterProvider',
        providerId,
        name,
        email,
        phone,
        transportMode
      );

      const savedProvider = await Provider.create({
        userId: providerId,
        name,
        email,
        phone,
        transportMode,
        password: password,
        businessName,
        serviceType,
        role: 'provider'
      });

      await initializeWallet({ user: { id: providerId } }, { // ✅ Wallet initialization
        status: () => ({
          json: () => {}
        })
      });

      console.log('✅ MongoDB provider saved:', savedProvider.userId);

      const token = jwt.sign(
        { id: providerId, role: 'provider', name, email },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE || '1d' }
      );

      res.status(201).json({
        message: 'Provider registered successfully',
        token,
        user: {
          id: providerId,
          name,
          email,
          phone,
          transportMode,
          role: 'provider'
        }
      });
    } catch (error) {
      console.error(`Error registering provider on blockchain: ${error}`);
      res.status(500).json({ error: `Failed to register provider: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in registerProvider: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Create a new ticket
const createTicket = async (req, res) => {
  try {
    const providerId = req.user.id;
    const {
      origin,
      destination,
      departureTime,
      arrivalTime,
      price,
      totalSeats,
      transportMode
    } = req.body;

    if (!origin || !destination || !departureTime || !arrivalTime || !price || !totalSeats || !transportMode) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const ticketId = `ticket_${uuidv4().slice(0, 6)}`;
    const { gateway, contract } = await getContractInstance(providerId);

    try {
      await contract.submitTransaction(
        'CreateTicket',
        ticketId,
        origin,
        destination,
        departureTime,
        arrivalTime,
        price.toString(),
        totalSeats.toString(),
        providerId,
        transportMode
      );

      res.status(201).json({
        message: 'Ticket created successfully',
        ticketId
      });
    } catch (error) {
      console.error(`Error creating ticket: ${error}`);
      res.status(500).json({ error: `Failed to create ticket: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in createTicket: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Get all provider tickets
const getProviderTickets = async (req, res) => {
  try {
    const providerId = req.user.id;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      const ticketsData = await contract.evaluateTransaction('QueryTicketsByProvider', providerId);
      const tickets = JSON.parse(ticketsData.toString());

      res.json(tickets);
    } catch (error) {
      console.error(`Error getting provider tickets: ${error}`);
      res.status(500).json({ error: `Failed to get tickets: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getProviderTickets: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Update dynamic price of a ticket
const updateTicketPrice = async (req, res) => {
  try {
    const providerId = req.user.id;
    const { ticketId } = req.params;
    const { gateway, contract } = await getContractInstance(providerId);

    try {
      const ticketData = await contract.evaluateTransaction('GetTicket', ticketId);
      const ticket = JSON.parse(ticketData.toString());

      if (ticket.serviceProvider !== providerId) {
        return res.status(403).json({ error: 'You are not authorized to update this ticket' });
      }

      await contract.submitTransaction('UpdateDynamicPrice', ticketId);

      const updatedTicketData = await contract.evaluateTransaction('GetTicket', ticketId);
      const updatedTicket = JSON.parse(updatedTicketData.toString());

      res.json({
        message: 'Ticket price updated successfully',
        oldPrice: ticket.dynamicPrice,
        newPrice: updatedTicket.dynamicPrice,
        ticket: updatedTicket
      });
    } catch (error) {
      console.error(`Error updating ticket price: ${error}`);
      res.status(500).json({ error: `Failed to update ticket price: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in updateTicketPrice: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Deactivate provider account
const deactivateAccount = async (req, res) => {
  try {
    const providerId = req.user.id;
    const { gateway, contract } = await getContractInstance(providerId);

    try {
      await contract.submitTransaction('DeregisterProvider', providerId);
      await Provider.findOneAndUpdate({ userId: providerId }, { isActive: false });

      res.json({
        message: 'Account deactivated successfully'
      });
    } catch (error) {
      console.error(`Error deactivating provider account: ${error}`);
      res.status(500).json({ error: `Failed to deactivate account: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in deactivateAccount: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// ✅ Export all handlers
module.exports = {
  getProviderProfile,
  createTicket,
  getProviderTickets,
  updateTicketPrice,
  deactivateAccount,
  registerProvider
};
