const BookingModel = require('../database/models/Booking');
const { getContractInstance } = require('../fabric/network');

// Helper to generate 6-char alphanumeric ID
const generateId = (prefix) => `${prefix}_${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

// Book a ticket
const bookTicket = async (req, res) => {
  try {
    const { customerId, ticketId, seatNumbers } = req.body;

    if (!customerId || !ticketId || !Array.isArray(seatNumbers) || seatNumbers.length === 0) {
      return res.status(400).json({ error: 'customerId, ticketId and seatNumbers (array) are required' });
    }

    const bookingId = generateId('booking');
    const { gateway, contract } = await getContractInstance(customerId);

    try {
      await contract.submitTransaction('BookTicket', bookingId, ticketId, customerId, JSON.stringify(seatNumbers));
      const bookingData = await contract.evaluateTransaction('GetBooking', bookingId);
      const booking = JSON.parse(bookingData.toString());

      // ✅ Patch optional field
      booking.paymentBlockHeight = booking.paymentBlockHeight || null;

      res.status(201).json({
        message: 'Ticket booked successfully',
        bookingId,
        booking,
        paymentRequired: true
      });
    } catch (error) {
      console.error(`Error booking ticket: ${error}`);
      res.status(500).json({ error: `Failed to book ticket: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in bookTicket: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// Confirm payment for a booking
const confirmPayment = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { bookingId, transactionId } = req.body;

    if (!bookingId || !transactionId) {
      return res.status(400).json({ error: 'bookingId and transactionId are required' });
    }

    const { gateway, contract } = await getContractInstance(customerId);

    try {
      await contract.submitTransaction('ConfirmPayment', bookingId, transactionId);
      const bookingData = await contract.evaluateTransaction('GetBooking', bookingId);
      const booking = JSON.parse(bookingData.toString());

      // ✅ Patch optional field
      booking.paymentBlockHeight = booking.paymentBlockHeight || null;

      // Optional: store in MongoDB
      await BookingModel.create({
        id: booking.id,
        ticketId: booking.ticketId,
        userId: booking.userId,
        seatIds: booking.seatIds,
        numberOfSeats: booking.numberOfSeats,
        totalPrice: booking.totalPrice,
        status: booking.status,
        isPaymentConfirmed: booking.isPaymentConfirmed,
        paymentBlockHeight: booking.paymentBlockHeight,
        createdAt: booking.createdAt,
        updatedAt: booking.updatedAt
      });

      const ticketData = await contract.evaluateTransaction('GetTicket', booking.ticketId);
      const ticket = JSON.parse(ticketData.toString());

      res.json({
        message: 'Payment confirmed successfully',
        booking,
        ticket: {
          id: ticket.id,
          origin: ticket.origin,
          destination: ticket.destination,
          departureTime: ticket.departureTime,
          arrivalTime: ticket.arrivalTime,
          serviceProvider: ticket.serviceProvider,
          transportMode: ticket.transportMode
        }
      });
    } catch (error) {
      console.error(`Error confirming payment: ${error}`);
      res.status(500).json({ error: `Failed to confirm payment: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in confirmPayment: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// Cancel a booking
const cancelBooking = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { bookingId } = req.params;
    const { gateway, contract } = await getContractInstance(customerId);

    try {
      const bookingData = await contract.evaluateTransaction('GetBooking', bookingId);
      const booking = JSON.parse(bookingData.toString());

      if (booking.userId !== customerId) {
        return res.status(403).json({ error: 'You are not authorized to cancel this booking' });
      }

      const refundAmount = booking.totalPrice * 0.8;
      await contract.submitTransaction('CancelBooking', bookingId);

      res.json({
        message: 'Booking cancelled successfully',
        refundAmount,
        booking
      });
    } catch (error) {
      console.error(`Error cancelling booking: ${error}`);
      res.status(500).json({ error: `Failed to cancel booking: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in cancelBooking: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

// Get booking by ID
const getBookingById = async (req, res) => {
  try {
    const customerId = req.user.id;
    const { id } = req.params;
    const { gateway, contract } = await getContractInstance('admin');

    try {
      const bookingData = await contract.evaluateTransaction('GetBooking', id);
      const booking = JSON.parse(bookingData.toString());

      if (booking.userId !== customerId && req.user.role !== 'admin') {
        return res.status(403).json({ error: 'You are not authorized to view this booking' });
      }

      const ticketData = await contract.evaluateTransaction('GetTicket', booking.ticketId);
      const ticket = JSON.parse(ticketData.toString());

      res.json({
        ...booking,
        ticket: {
          id: ticket.id,
          origin: ticket.origin,
          destination: ticket.destination,
          departureTime: ticket.departureTime,
          arrivalTime: ticket.arrivalTime,
          serviceProvider: ticket.serviceProvider,
          transportMode: ticket.transportMode,
          price: ticket.price,
          dynamicPrice: ticket.dynamicPrice
        }
      });
    } catch (error) {
      console.error(`Error getting booking: ${error}`);
      res.status(500).json({ error: `Failed to get booking: ${error.message}` });
    } finally {
      gateway.disconnect();
    }
  } catch (error) {
    console.error(`Error in getBookingById: ${error}`);
    res.status(500).json({ error: 'Server error' });
  }
};

module.exports = {
  bookTicket,
  confirmPayment,
  cancelBooking,
  getBookingById
};
